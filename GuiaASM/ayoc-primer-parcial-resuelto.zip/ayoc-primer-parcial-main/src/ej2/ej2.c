#include "../ejs.h"

void borrarDeFeedUsuario(usuario_t *usuario, uint32_t id_a_borrar) {
    
  feed_t* feedUsuario = usuario->feed;
  publicacion_t* publicacion = feedUsuario->first;
  
  // Voy a asegurarme que el primero no sea uno a borrar (para podes mantener un invariante más sencillo)
  while (publicacion != NULL && publicacion->value->id_autor == id_a_borrar) {
    feedUsuario->first = publicacion->next;
    free(publicacion);
    publicacion = feedUsuario->first;
  }

  while (publicacion != NULL) {
    // Invariante publicacion y todos sus anteriores no tienen el id_a_borrar
    publicacion_t* publicacionNext = publicacion->next;
    if (publicacionNext == NULL) {
        //Sabemos que es el ultimo, por invariante publicBloqueado no es, 
        //Ya esta
        publicacion = publicacion->next;
      continue;
    } 
    //Sabemos que tiene al menos un siguiente

    //Verificamos si el isguiente es para borrar o no
    if(publicacion->next->value->id_autor == id_a_borrar) {
      while (publicacion->next != NULL && publicacion->next->value->id_autor == id_a_borrar) {
        publicacion_t* publicacionABorrar = publicacion->next;
        publicacion->next = publicacion->next->next;
        free(publicacionABorrar);
      }
    } 
    publicacion = publicacion->next;
  }
}

void bloquearUsuario(usuario_t *usuario, usuario_t *usuarioABloquear){
  /*
    Agregar el usuario bloqueado al final del arreglo de usuarios bloqueados.
  Borrar todas las publicaciones del feed del usuario bloqueador que contengan tuits del usuario bloqueado.
  Borrar todas las publicaciones del feed del usuario bloqueado que contengan tuits del usuario bloqueador.
  */
  uint32_t numBloqueados = usuario->cantBloqueados;
  usuario->bloqueados[numBloqueados] = usuarioABloquear;
  usuario->cantBloqueados++;
  usuario->bloqueados[numBloqueados + 1] = NULL;

  feed_t* feedBloqueador = usuario->feed;
  publicacion_t* publiBloquedaor = feedBloqueador->first;
  uint32_t bloqueado = usuarioABloquear->id;

  // Voy a asegurarme que el primero no sea uno a borrar (para podes mantener un invariante más sencillo)
  borrarDeFeedUsuario(usuario, usuarioABloquear->id);
  borrarDeFeedUsuario(usuarioABloquear, usuario->id);
  return;
}
