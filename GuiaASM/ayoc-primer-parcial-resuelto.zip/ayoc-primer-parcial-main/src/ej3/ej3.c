#include "../ejs.h"

tuit_t **trendingTopic(usuario_t *user, uint8_t (*esTuitSobresaliente)(tuit_t *)) {
    // Recorrer todo el feed
    // Si es tuit del usuario, verificar si es sobresaliente
    // Si lo es, agregar 1 a cantidadSobresaliente
    
    //pedir 8 * cantidadSobresaliente
    
    //Recorrer el feed y verificar si es del usuario y sobresaliente.
    //      Agregarlo en la posicion j del arreglo
    //      j++
    int cantSobresalientes = 0;
    feed_t* feed = user->feed;
    publicacion_t* public = feed->first;
    uint32_t idAutor = user->id;
    while (public != NULL) {
        tuit_t *tuitDelFeed = public->value;
        uint32_t autorTuit = tuitDelFeed->id_autor;
        uint8_t esSobresaliente = esTuitSobresaliente(tuitDelFeed);
        if (autorTuit == idAutor && esSobresaliente == 1) {
            cantSobresalientes++;
        } 
        public = public->next;
    }
    if (cantSobresalientes == 0) {
        return NULL;
    }

    tuit_t** res = malloc(64 * (cantSobresalientes + 1));
    int j = 0;
    public = feed->first;
    while (public != NULL) {
        tuit_t *tuitDelFeed = public->value;
        uint32_t autorTuit = tuitDelFeed->id_autor;
        uint8_t esSobresaliente = esTuitSobresaliente(tuitDelFeed);
        if (autorTuit == idAutor && esSobresaliente == 1) {
            res[j] = tuitDelFeed;
            j++;
        } 
        public = public->next;
    }
    res[j] = NULL;

    return res;
}
