#include "../ejs.h"
#include <string.h>

// Función principal: publicar un tuit
tuit_t *publicar(char *mensaje, usuario_t *user) {
  tuit_t *tuit = malloc(sizeof(tuit_t));
  
  tuit->favoritos = 0;
  tuit->id_autor = user->id;
  strcpy(tuit->mensaje, mensaje);

  feed_t* feedUsuario = user->feed;
  publicacion_t* publicacion = malloc(sizeof(publicacion_t));
  publicacion->next =feedUsuario->first;
  publicacion->value = tuit;
  feedUsuario->first = publicacion;

  usuario_t **seguidores = user->seguidores;
  
  for(int i = 0; i < user->cantSeguidores; i++) {
    usuario_t *seguidor = seguidores[i];
    feed_t* feedSeguidor = seguidor->feed;
    publicacion_t* publicacionFeedSeguidores = malloc(sizeof(publicacion_t));
    publicacionFeedSeguidores->next = feedSeguidor->first;
    publicacionFeedSeguidores->value = tuit;

    feedSeguidor->first = publicacionFeedSeguidores;
  }
  
  return tuit;
}
